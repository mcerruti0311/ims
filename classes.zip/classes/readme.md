# ReadMe

## Order of execution

1. locatonDataCreator
1. sisAccountCreator
1. vendorAccountCreator
1. operationsAccountCreator
1. imsCreator
1. contactCreator
